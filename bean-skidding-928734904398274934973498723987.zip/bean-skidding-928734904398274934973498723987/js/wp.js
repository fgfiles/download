
function pause() {
	window.pauseGame();
}

function unpause() {
	window.unpauseGame();
}

function mute() {
	window.muteGame();
}

function unmute() {
	window.unmuteGame();
}

function reload() {
	window.reloadGame();
}

function submitUserRank(rank) {
	location.href = rank;
}