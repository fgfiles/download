
    game1= {
        title: "page title",
        desciption: "page description",
        pages: {
            intro: {

                game_title:{
                    text: "MATCHING PAIRS",
                    x:25,
                    y:0,
                    font:"50px Cervo"
                },
                ticker_t1:{
                    text: "STARTS",
                    x:0,
                    y:0,
                    font:"51px Cervo"

                },
                ticker_t2:{
                    text: "1st October at 5pm",
                    x:0,
                    y:0,
                    font:"35px Cervo"

                },

                htp:{
                    text: "HOW TO PLAY",
                    x:0,
                    y:0,
                    font:"40px Cervo"

                }
            },
            select_level:{
                easy:{
                    text:"Easy",
                    x:0,
                    y:0,
                    font:"40px Cervo"
                },
                hard:{
                    text:"Medium",
                    x:0,
                    y:0,
                    font:"40px Cervo"
                },
				
                veryhard:{
                    text:"Hard",
                    x:0,
                    y:0,
                    font:"40px Cervo"
                },
                extrahard:{
                    text:"Very Hard",
                    x:0,
                    y:0,
                    font:"40px Cervo"
                }


            },
            game:{
                time:{
                    text:"TIME",
                    x:0,
                    y:0,
                    font:"24px Cervo"
                },
                timer:{
                    text:"00:00",
                    x:0,
                    y:0,
                    font:"41px Cervo"
                }
            },
            game_over:{
                congratulations:{
                    text:"Well done!\nYou did it!",
                    x:0,
                    y:0,
                    font:"66px Cervo"
                },
                your_time:{
                    text:"Your Time: ",
                    x:0,
                    y:0,
                    font:"48px Cervo"
                },
                time:{
                    text:"00:00",
                    x:0,
                    y:0,
                    font:"70px Cervo"
                },
                play_again:{
                    text:"Play Again",
                    x:0,
                    y:0,
                    font:"34px Cervo"
                },
                next_level:{
                    text:"Next Level",
                    x:0,
                    y:0,
                    font:"34px Cervo"
                }
            }

        }
    };


